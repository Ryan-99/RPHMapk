#!bin/sh

echo "================================运行脚本前请确定adb已连接============================="

home=$(pwd)
system=$home/system
app=$system/app
framework=$system/framework
temp_framework=$system/temp_framework
dex=$home/dex
tmp=$home/tmp

echo "==================================正在从设备上提取软件================================"

if test -d $tmp
then
	rm -rf $tmp
	mkdir -p $tmp
else
	mkdir -p $tmp
fi

if test -d $framework
then
	echo "framework目录已存在，无需下载"
else
	mkdir -p $framework
	adb pull /system/framework/ $framework
fi

if test -d $app
then
	echo "app目录已存在，无需下载"
else
	mkdir -p $app
	adb pull /system/app/ $app
fi


vdexExtractor(){
	files=`find $app -name "*.vdex"`
	cd $home/vdexExtractor
	if test -d $$home/vdexExtractor/bin/vdexExtractor
	then
		chmod +x make.sh
		./make.sh
	fi
	cd $home/vdexExtractor/bin
	for file in $files 
	do
    	./vdexExtractor -i $file
	done
	cd $home
}
vdexExtractor;

dedeox () {
	ap=`find $app -name "*.apk"`
	if test -d $tmp/oapp
	then
		rm -rf $tmp/oapp
		mkdir -p $tmp/oapp
	else
		mkdir -p $tmp/oapp
	fi
	cp $ap $tmp/oapp
	appk=`basename -s .apk $ap`
	jar=`find $app -name "*.jar"`
	odexx=`find $app -name "*.odex"`
	for tool in baksmali.jar smali.jar oat2dex.jar 
		do
			cp $home/SmaliEx/$tool $home
		done
	for oodex in $odexx 
		do
			cp $oodex $home/tmp
		done
	for apk in $appk
	do
		mkdir -p tmp/oapp/$apk
		if [ -f $apk ]; then
   	 		echo "Dedeoxing $apk.apk"
		elif [ -f $jar ]; then
   			 echo "Dedeoxing $apk.apk"
		fi
		cp $app/apk tmp
		##java -jar -Duser.language=en oat2dex.jar $apk.odex tmp/$apk.dex > /dev/null 2>&1
		java -jar baksmali.jar x tmp/$apk.odex -o tmp/$apk
		java -jar smali.jar a tmp/$apk -o tmp/$apk/classes.dex
		if [ -f $apk.apk ]; then
    		echo "$apk.apk classes.dex created"
		elif [ -f $apk.jar ]; then
    		echo "$apk.jar classes.dex created"
		fi
		echo
	done
	for tool in baksmali.jar smali.jar oat2dex.jar 
		do
			rm $home
		done
	for oodex in $odexx 
		do
			rm $home/tmp
		done
}
dedeox;


